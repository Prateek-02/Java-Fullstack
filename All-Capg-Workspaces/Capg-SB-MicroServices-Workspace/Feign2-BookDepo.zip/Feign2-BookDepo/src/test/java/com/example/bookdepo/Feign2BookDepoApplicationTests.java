package com.example.bookdepo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Feign2BookDepoApplicationTests {

	@Test
	void contextLoads() {
	}

}

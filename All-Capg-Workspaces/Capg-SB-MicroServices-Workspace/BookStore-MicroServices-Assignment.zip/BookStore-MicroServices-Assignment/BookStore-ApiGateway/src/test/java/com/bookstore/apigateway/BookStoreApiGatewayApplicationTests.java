package com.bookstore.apigateway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookStoreApiGatewayApplicationTests {

	@Test
	void contextLoads() {
	}

}

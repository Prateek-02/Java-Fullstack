package com.example.bookinfo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Feign2BookInfoApplicationTests {

	@Test
	void contextLoads() {
	}

}

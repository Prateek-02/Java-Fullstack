package com.springcore;

public interface EmployeeService {
	public void EmployeeDetails();
}

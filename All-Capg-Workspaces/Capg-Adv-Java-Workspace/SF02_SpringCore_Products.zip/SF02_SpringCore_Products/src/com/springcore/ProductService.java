package com.springcore;

public interface ProductService {
	public void allProducts();
}
